// Configuration settings
module.exports = {
    mongoURI: 'mongodb+srv://kevinghobrial:C8GijB5%2F%21%21@cluster0.1jcxqor.mongodb.net/mydatabase?retryWrites=true&w=majority',
    jwtSecret: 'XgaYfXTNL;oh-Yc',
  };
  