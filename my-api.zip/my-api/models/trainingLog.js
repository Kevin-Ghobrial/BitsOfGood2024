const mongoose = require('mongoose');

const trainingLogSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  activity: { type: String, required: true },
  animal: { type: mongoose.Schema.Types.ObjectId, ref: 'Animal', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
});

const TrainingLog = mongoose.model('TrainingLog', trainingLogSchema);

module.exports = TrainingLog;
