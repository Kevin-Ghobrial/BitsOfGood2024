const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();
app.use(bodyParser.json());

// Replace with your MongoDB connection string
const mongoURI = 'mongodb+srv://kevinghobrial:C8GijB5%2F%21%21@cluster0.1jcxqor.mongodb.net/mydatabase?retryWrites=true&w=majority';
const jwtSecret = 'your_jwt_secret';

mongoose.connect(mongoURI)
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error.message);
  });

// User Schema
const userSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
});

userSchema.pre('save', async function(next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 10);
  }
  next();
});

const User = mongoose.model('User', userSchema);

// Animal Schema
const animalSchema = new mongoose.Schema({
  name: { type: String, required: true },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
});

const Animal = mongoose.model('Animal', animalSchema);

// Training Log Schema
const trainingLogSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  activity: { type: String, required: true },
  animal: { type: mongoose.Schema.Types.ObjectId, ref: 'Animal', required: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
});

const TrainingLog = mongoose.model('TrainingLog', trainingLogSchema);

// Middleware to authenticate JWT
const authenticateJWT = (req, res, next) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (!token) return res.sendStatus(403);

  jwt.verify(token, jwtSecret, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Root route
app.get('/', (req, res) => {
  res.send('Welcome to the API! Use /api/health, /api/user, /api/animal, or /api/training for API endpoints.');
});

// GET /api/health - Check if the server is healthy
app.get('/api/health', (req, res) => {
  res.status(200).json({ healthy: true });
});

// POST /api/user - Create a new user
app.post('/api/user', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = new User({ email, password });
    await user.save();
    res.status(200).json(user);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// POST /api/animal - Create a new animal
app.post('/api/animal', authenticateJWT, async (req, res) => {
  try {
    const { name } = req.body;
    const animal = new Animal({ name, owner: req.user._id });
    await animal.save();
    res.status(200).json(animal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// POST /api/training - Create a new training log
app.post('/api/training', authenticateJWT, async (req, res) => {
  try {
    const { date, activity, animalId } = req.body;
    const animal = await Animal.findOne({ _id: animalId, owner: req.user._id });
    if (!animal) return res.status(400).json({ error: 'Animal not owned by user' });

    const trainingLog = new TrainingLog({ date, activity, animal: animalId, user: req.user._id });
    await trainingLog.save();
    res.status(200).json(trainingLog);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// POST /api/user/login - Authenticate user
app.post('/api/user/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(403).json({ error: 'Invalid email or password' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(403).json({ error: 'Invalid email or password' });

    const token = jwt.sign({ _id: user._id, email: user.email }, jwtSecret, { expiresIn: '1h' });
    res.status(200).json({ token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST /api/user/verify - Issue a JWT if email/password is valid
app.post('/api/user/verify', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(403).json({ error: 'Invalid email or password' });

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) return res.status(403).json({ error: 'Invalid email or password' });

    const token = jwt.sign({ _id: user._id, email: user.email }, jwtSecret, { expiresIn: '1h' });
    res.status(200).json({ token, user });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/admin/users - Get all users with pagination
app.get('/api/admin/users', authenticateJWT, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const users = await User.find()
      .select('-password') // Exclude passwords
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/admin/animals - Get all animals with pagination
app.get('/api/admin/animals', authenticateJWT, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const animals = await Animal.find()
      .populate('owner', 'email')
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.status(200).json(animals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/admin/training - Get all training logs with pagination
app.get('/api/admin/training', authenticateJWT, async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const trainingLogs = await TrainingLog.find()
      .populate('animal user', 'name email')
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.status(200).json(trainingLogs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Start the server
const port = process.env.PORT || 3012;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
