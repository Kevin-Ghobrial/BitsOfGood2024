const express = require('express');
const router = express.Router();
const TrainingLog = require('../models/trainingLog');
const Animal = require('../models/animal');

// POST /api/training - Create a new training log
router.post('/', async (req, res) => {
  try {
    const { date, activity, animalId } = req.body;
    const animal = await Animal.findOne({ _id: animalId, owner: req.user._id });
    if (!animal) return res.status(400).json({ error: 'Animal not owned by user' });

    const trainingLog = new TrainingLog({ date, activity, animal: animalId, user: req.user._id });
    await trainingLog.save();
    res.status(200).json(trainingLog);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
