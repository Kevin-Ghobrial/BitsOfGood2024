const express = require('express');
const router = express.Router();
const Animal = require('../models/animal');

// POST /api/animal - Create a new animal
router.post('/', async (req, res) => {
  try {
    const { name } = req.body;
    const animal = new Animal({ name, owner: req.user._id });
    await animal.save();
    res.status(200).json(animal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
