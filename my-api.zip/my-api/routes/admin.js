const express = require('express');
const router = express.Router();
const User = require('../models/user');
const Animal = require('../models/animal');
const TrainingLog = require('../models/trainingLog');

// GET /api/admin/users - Get all users with pagination
router.get('/users', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const users = await User.find()
      .select('-password') // Exclude passwords
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.status(200).json(users);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/admin/animals - Get all animals with pagination
router.get('/animals', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const animals = await Animal.find()
      .populate('owner', 'email')
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.status(200).json(animals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/admin/training - Get all training logs with pagination
router.get('/training', async (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query;
    const trainingLogs = await TrainingLog.find()
      .populate('animal user', 'name email')
      .skip((page - 1) * limit)
      .limit(Number(limit));
    res.status(200).json(trainingLogs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
