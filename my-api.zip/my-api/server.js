const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const { mongoURI, jwtSecret } = require('./config');
const authRoutes = require('./routes/auth');
const animalRoutes = require('./routes/animal');
const trainingRoutes = require('./routes/training');
const adminRoutes = require('./routes/admin');

const app = express();
app.use(bodyParser.json());

mongoose.connect(mongoURI)
  .then(() => console.log('Connected to MongoDB'))
  .catch((error) => console.error('Error connecting to MongoDB:', error.message));

// Middleware to authenticate JWT
const { authenticateJWT } = require('./middlewares/authenticateJWT');

// Root route
app.get('/', (req, res) => {
  res.send('Welcome to the API! Use /api/health, /api/user, /api/animal, or /api/training for API endpoints.');
});

// Use routes
app.use('/api/user', authRoutes);
app.use('/api/animal', authenticateJWT, animalRoutes);
app.use('/api/training', authenticateJWT, trainingRoutes);
app.use('/api/admin', authenticateJWT, adminRoutes);

// Start the server
const port = process.env.PORT || 6000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
